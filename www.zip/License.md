Read full license terms @ https://creativecommons.org/licenses/by-nd/3.0/

You are free to:

Share — copy and redistribute the material in any medium or format
for any purpose, even commercially.

If you like to make any modification to this application please contact support@openspeedtest.com 

The licensor cannot revoke these freedoms as long as you follow the license terms.

Under the following terms:

Attribution — 

You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

NoDerivatives — 

If you remix, transform, or build upon the material, you may not distribute the modified material.

No additional restrictions — 

You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Please donate! https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TY2D56BYPKEXU if you like our work!